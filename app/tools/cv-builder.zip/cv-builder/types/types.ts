export type ExperienceItem = {
  title: string;
  company: string; // ✅ This line is missing
  startDate: string;
  endDate: string;
  description: string;
};
